import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //ЗАДАЧА 8.1      OOP

        Scanner scanner = new Scanner(System.in);
        Треугольник три = new Треугольник();
        System.out.println(" Введите ширину треугольника: ");
        три.ширина = scanner.nextDouble();
        System.out.println(" Введите высоту треугольника: ");
        три.высата = scanner.nextDouble();
        double aa=  три.площадь();
        System.out.println(" Площать треугольника "+aa);

        //ЗАДАЧА 8.2      OOP

        //Scanner scanner = new Scanner(System.in);

    }
}