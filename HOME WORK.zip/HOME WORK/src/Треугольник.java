public class Треугольник {
        double ширина;
        double высата;
        double cc= 2;


        public double площадь() {
            return (ширина * высата)/cc;
        }
    }